import React from "react";

function App() {
  return (
    <div>
      <h1>Fullstack Java Task</h1>
      <p>React Frontend Ready</p>
    </div>
  );
}

export default App;